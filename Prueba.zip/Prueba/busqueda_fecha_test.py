import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import os
import time

@pytest.fixture(scope="module")
def driver():
    # Configuración del servicio del controlador de Chrome
    service = Service(executable_path="C:\chromedriver.exe")
    driver = webdriver.Chrome(service=service)
    yield driver
    driver.quit()

def test_google_search_sort_by_date(driver):
    driver.get("https://www.google.com")

WebDriverWait(driver, 5).until(
    EC.presence_of_element_located((By.CLASS_NAME, "gLFyf"))
)

input_element = driver.find_element(By.CLASS_NAME, "gLFyf")
input_element.clear()
input_element.send_keys("Yahoo" + Keys.ENTER)

WebDriverWait(driver, 5).until(EC.presence_of_element_located((By.ID, "hdtb-tls")))

    tools_button = driver.find_element(By.ID, "hdtb-tls")
    tools_button.click()

    WebDriverWait(driver, 5).until(EC.presence_of_element_located((By.XPATH, "//a[text()='Fecha']")))

    date_option = driver.find_element(By.XPATH, "//a[text()='Fecha']")
    date_option.click()

    WebDriverWait(driver, 5).until(EC.presence_of_element_located((By.CLASS_NAME, "g")))

    driver.save_screenshot("result/screenshot_sort_by_date.png")

if __name__ == "__main__":
    if not os.path.exists("result"):
        os.makedirs("result")
        
    pytest.main(args=["-v", "--html=report.html"])